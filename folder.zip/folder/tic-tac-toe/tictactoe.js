let counter = 1;
let boxes = document.querySelectorAll(".boxes");
let container = document.querySelector(".mainBox");
let board = Array(9).fill(null);
let currentPlayer = 'X'; 
let player1 = document.querySelector(".player1");
let player2 = document.querySelector(".player2");

boxes.forEach((box, index) => {
    box.addEventListener('click', function() {
        if (!board[index]) {
            board[index] = currentPlayer;
            if (currentPlayer === 'X') {
                box.firstElementChild.style.display = 'block';
                player1.classList.toggle('playeroff')
                player2.classList.toggle('playeroff')
            } else {
                box.lastElementChild.style.display = 'block';
                player1.classList.toggle('playeroff')
                player2.classList.toggle('playeroff')
            }
            if (checkWin()) {
                alert(`${currentPlayer} wins!`);
                resetGame();
            } else if (board.every(cell => cell)) {
                alert("It's a draw!");
                resetGame();
            } else {
                currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
            }
        }
    });
});

const winningMoves = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];

function checkWin() {
    for (let i = 0; i < winningMoves.length; i++) {
        let combination = winningMoves[i];
        let win = true;
        for (let j = 0; j < combination.length; j++) {
            if (board[combination[j]] !== currentPlayer) {
                win = false;
                break;
            }
        }
        if (win) {
            return true;
        }
    }
    return false;
}

function resetGame() {
    board.fill(null);
    boxes.forEach(box => {
        box.firstElementChild.style.display = 'none'; 
        box.lastElementChild.style.display = 'none'; 
    });
    currentPlayer = 'X';
}
