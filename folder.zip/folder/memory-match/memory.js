class MemoryMatch{
    constructor(){
        this.tilesCount = 20;
        this.cardContainer = document.querySelector('.card-container');
        this.cards = document.querySelectorAll('.card');
        this.tiles = [];
        this.tilesChecked = [] 
        this.availableClick = true;
        this.tilesClick = this.tilesClick.bind(this);
        this.pairCount = 0;
        this.newGameButton = document.querySelector('.memory-start-button');
        this.gameOverCard = document.querySelector('.game-over-card');
        this.playAgainButton = document.querySelector('.play-again-button');
        this.playAgainButton.addEventListener('click', () => {
            this.startGame();
            this.gameOverCard.classList.remove('show')
            this.newGameButton.disabled = false
        })
        this.tilesImages = [
            '../images/assembly.png',
            '../images/html.png',
            '../images/css.png',
            '../images/java.png',
            '../images/cpp.png',
            '../images/php.png',
            '../images/python.png',
            '../images/ruby.png',
            '../images/rust.png',
            '../images/js.png',
        ]
    } 
    shuffle(array){
        for (let i = array.length - 1; i >= 1; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }
    tilesClick(tile){
        if(this.availableClick){
            if(!this.tilesChecked[0] || this.tilesChecked[0] !== tile.target){
                this.tilesChecked.push(tile.target);
                tile.target.style.backgroundImage = `url(${this.tilesImages[tile.target.dataset.tile]})`;
                tile.target.setAttribute('aria-label', 'card shown: ' + this.tilesImages[tile.target.dataset.tile].slice(10,-4));
            }
            if(this.tilesChecked.length === 2){
                this.availableClick = false;
                if(this.tilesChecked[0].dataset.tile === this.tilesChecked[1].dataset.tile){
                    this.acceptTiles()
                } else {
                    this.resetTiles()
                }
            }
    }
    }
    acceptTiles(){
        setTimeout( () => {
            this.tilesChecked.forEach(tile => {
                tile.style.backgroundImage = ``;
                tile.classList.add('accept');
                tile.setAttribute('aria-label', 'Matched card');
                tile.removeEventListener('click', this.tilesClick);
                this.availableClick = true;
                this.tilesChecked = [];
            })
            this.pairCount++;
            if(this.pairCount === this.tilesCount/2){
                setTimeout(() => {
                    this.gameOverCard.classList.add('show')
                    this.newGameButton.disabled = true
                    this.gameOverCard.children[2].innerText = `you won in  `
                }, 500);
            }
        },800)
    }
    resetTiles(){
        setTimeout(() => {
            this.tilesChecked.forEach(tile => {
                tile.style.backgroundImage = ``;
                this.availableClick = true;
                this.tilesChecked = [];
                tile.setAttribute('aria-label', 'Hidden card');
            })
        }, 800);
    }
    generateTiles(){
        for (let i=0; i < this.tilesCount; i++) {
            this.tiles.push(Math.floor(i/2));
        }
        this.tiles = this.shuffle(this.tiles);

        for (let i = 0; i < this.tilesCount; i++){
            const card = document.createElement('div');
            card.classList.add('card');
            card.setAttribute('role', 'button');
            card.setAttribute('aria-label', 'Hidden card');
            card.dataset.index = i;
            card.dataset.tile = this.tiles[i];
            this.cardContainer.appendChild(card);

            card.addEventListener('click' ,this.tilesClick); 
        }
    }
    startGame(){
        this.cardContainer.innerHTML = '';
        this.tiles = []
        this.tilesChecked = []
        this.availableClick = true;
        this.pairCount = 0;
        this.generateTiles();
    }
}
const memoryMatch = new MemoryMatch();

const startButton = document.querySelector('.memory-start-button');
startButton.addEventListener('click', () => {
    memoryMatch.startGame();
})
