let hamburgerButton = document.querySelector('.hamburger-button');
let menuMobile = document.querySelector('.mobile-menu');
let hamburgerLineIcon = document.querySelector(".hamburger-icon-lines")
let hamburgerXIcon = document.querySelector(".hamburger-icon-x")

console.log(hamburgerLineIcon)
console.log(hamburgerXIcon)
function showMenu(){
    menuMobile.classList.toggle('menu-show')
    hamburgerLineIcon.classList.toggle('hide')
    hamburgerXIcon.classList.toggle('hide')
};