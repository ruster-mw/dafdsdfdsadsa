class Hangman {
    constructor() {
        this.currentPhrase = null;
        this.currentPhraseletters = null;
        this.guessedLetters = null;
        this.attemps = 7;
        this.phraseElem = document.getElementById("phrase");
        this.lettersElem = document.getElementById("letters");
        this.attempsElem = document.getElementById("attemps");
        this.gameOverCard = document.querySelector('.game-over-card');
        this.newPhraseButton = document.querySelector('.phrase-button');
        this.canvas = document.getElementById('hangman-canvas');
        this.ctx = this.canvas.getContext('2d');
        this.phrases = [
            "Elephant",
            "Pineapple",
            "Spaceship",
            "Rainbow",
            "Notebook",
            "Thunder",
            "Whistle",
            "Journey",
            "Mystery",
            "Treasure",
            "Backpack",
            "Galaxy",
            "Lantern",
            "Pumpkin",
            "Castle"
        ];
    }

    generateLetters(){
        const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        letters.split('').forEach((letter) => {
            const letterButton = document.createElement('button')
            letterButton.classList.add('letter')
            letterButton.innerText = letter
            this.lettersElem.appendChild(letterButton)
        })
    }
    letterClick(){
        this.lettersElem.addEventListener('click', (e) => {
            if (e.target.tagName === 'BUTTON'){
                e.target.disabled = true
                const letter = e.target.innerText
                const phraseBoxes = this.phraseElem.querySelectorAll('.phrase-letter')
                let letterFound = false
                this.currentPhraseletters.forEach((phraseletter, index) => {
                    if (phraseletter.toUpperCase() == letter){
                        phraseBoxes[index].innerText = phraseletter
                        letterFound = true
                    }
                })    
                if (!letterFound){
                    this.drawHangman(this.attemps)
                    this.attemps--
                }
                this.updateAttemps()
            }
        })
    }
    enableLetters(){
        const letters = this.lettersElem.querySelectorAll('.letter')
        letters.forEach((letter) => {
            letter.disabled = false
        })
    }
    disableLetters(){
        const letters = this.lettersElem.querySelectorAll('.letter')
        letters.forEach((letter) => {
            letter.disabled = true
        })
    }
    drawHangman(index){
        switch(index){
            case 7:
                this.ctx.strokeStyle = "#9595dd"
                this.ctx.lineWidth = 5
                this.ctx.beginPath()
                this.ctx.moveTo(50,200)
                this.ctx.lineTo(200,200)
                this.ctx.stroke()
            break;
            case 6:
                this.ctx.moveTo(120,200)
                this.ctx.lineTo(120,50)
                this.ctx.stroke()
            break;
            case 5:
                this.ctx.lineTo(200,50)
                this.ctx.lineTo(200,70)
                this.ctx.stroke()
            break;
            case 4:
                this.ctx.beginPath()
                this.ctx.arc(200,90,20,0,Math.PI * 2)
                this.ctx.stroke()
            break;
            case 3:
                this.ctx.beginPath()
                this.ctx.moveTo(200,110)
                this.ctx.lineTo(200,150)
                this.ctx.stroke()
            break;
            case 2:
                this.ctx.moveTo(200,120)
                this.ctx.lineTo(175,140)
                this.ctx.moveTo(200,120)
                this.ctx.lineTo(225,140)
                this.ctx.stroke()
            break;
            case 1:
                this.ctx.moveTo(200,150)
                this.ctx.lineTo(185,190)
                this.ctx.moveTo(200,150)
                this.ctx.lineTo(215,190)
                this.ctx.stroke()
        }
    }
    updateAttemps(){
        this.attempsElem.innerText = this.attemps
        if (this.attemps <= 0){
            this.disableLetters()
            this.gameOverCard.classList.add('show')
            this.newPhraseButton.disabled = true
            this.gameOverCard.children[0].src = '../images/lose.png'
            this.gameOverCard.children[1].innerText = 'You lost :('
            this.gameOverCard.children[3].innerText = 'the phrase was: ' + this.currentPhrase
        }
        const phraseBoxes = this.phraseElem.querySelectorAll('.phrase-letter')
        const allLettersGuessed = Array.from(phraseBoxes).every((box) => {
            return box.innerText !== ''
        })
        if(allLettersGuessed){
            this.disableLetters()
            this.gameOverCard.classList.add('show')
            this.newPhraseButton.disabled = true
            this.gameOverCard.children[3].innerText = 'the phrase was: ' + this.currentPhrase
        }
    }
    
    generatePhrase(){
        let randomIndex = Math.floor(Math.random() * this.phrases.length)
        let randomPhrase = this.phrases[randomIndex]
        this.currentPhrase = randomPhrase
        this.currentPhraseletters = randomPhrase.split('')
        randomPhrase.split('').forEach((letter) => {
            const letterDiv = document.createElement('div')
            letterDiv.classList.add('phrase-letter')
            this.phraseElem.appendChild(letterDiv)
        })
    }

    startGame(){
        this.attemps = 7
        this.attempsElem.innerText = this.attemps
        this.enableLetters()
        this.phraseElem.innerHTML = ''
        this.generatePhrase()
    }
    initGame(){
        this.generateLetters()
        this.generatePhrase()
        this.letterClick()
    }

}
let game = new Hangman()
let phraseButton = document.querySelector('.phrase-button')
phraseButton.addEventListener('click', () => {
    game.phraseElem.innerHTML = ''
    game.startGame()
})
let playAgainButton = document.querySelector('.play-again-button')
playAgainButton.addEventListener('click', () => {
    game.gameOverCard.classList.remove('show')
    game.newPhraseButton.disabled = false
    game.startGame()
    game.ctx.clearRect(0,0,game.canvas.width,game.canvas.height)
})
let rageQuitButton = document.querySelector('.rage-quit-button')
rageQuitButton.addEventListener('click', () => {
    window.location.href = '/mainpage/index.html'
})
document.addEventListener('DOMContentLoaded',() => {
    game.initGame()
})














