class Snake {
    constructor(ctx){
        this.ctx = ctx
        this.pixels = 26
        this.speed = 110
        this.pixelSize = canvas.width / this.pixels
        this.snake = []
        this.direction = {x: -1 ,y: 0}
        this.score = 0
        this.food = this.createFood()
        this.scoreElement = document.querySelector("#score")
        this.temporary = []
        this.gameOverCard = document.querySelector('.game-over-card')
        this.gameOver = false
        this.topScore = document.querySelector('.top-score')
    }
    updateBackground(){
        ctx.fillStyle = '#1a1a1a'
        ctx.fillRect(0, 0, canvas.width, canvas.height)
    } 
    createFood(){
        let food
        do{
            food = {
                x: Math.floor(Math.random() * this.pixels),
                y: Math.floor(Math.random() * this.pixels)
            }
        } while(this.snake.some(segment => segment.x === food.x && segment.y === food.y))
        return food
    }
    drawFood(){
        ctx.fillStyle = 'red'
        ctx.fillRect(this.food.x *this.pixelSize, this.food.y * this.pixelSize, this.pixelSize, this.pixelSize)
    }
    drawSnake(){
        this.updateBackground()
        this.drawFood()
        ctx.fillStyle = 'green'
        this.snake.forEach(segment => { 
            ctx.fillRect(segment.x * this.pixelSize , segment.y * this.pixelSize , this.pixelSize , this.pixelSize)
        })
    }
    moveSnake(){       
        this.drawSnake()
        setTimeout(() => {
            this.temporary = this.snake.map(s => ({ x: s.x, y: s.y }));
            this.snake.forEach((segment,index) =>{
                if (index !== 0){
                    segment.x = this.temporary[index - 1].x
                    segment.y = this.temporary[index - 1].y
                }else{
                    segment.x += this.direction.x
                    segment.y += this.direction.y
                }
            })
            if(this.snake[0].x === this.food.x && this.snake[0].y === this.food.y){
                this.score++
                this.scoreElement.innerText = "Score: " + this.score
                const lastSegment = this.snake[this.snake.length - 1]
                this.snake.push({x: lastSegment.x, y: lastSegment.y})
                this.food = this.createFood()
                this.drawFood()
            }
            if(this.snake[0].x < 0 || this.snake[0].x >= this.pixels || this.snake[0].y < 0 || this.snake[0].y >= this.pixels){
                this.gameOver = true
            }
            if(this.snake.some((segment,index) => {
                return index !== 0 && segment.x === this.snake[0].x && segment.y === this.snake[0].y
            }) && this.snake.length >= 3){
                this.gameOver = true
            }
            if(!this.gameOver)
                this.moveSnake()
            else{
                this.gameOverCard.classList.add('show')
                this.gameOverCard.children[2].innerText = 'your score is: ' + this.score
                if (this.score > JSON.parse(localStorage.getItem('topScore'))) {
                    localStorage.setItem('topScore', JSON.stringify(this.score));
                    this.topScore.innerText = 'Top Score: ' + this.score
                }
            }
        },this.speed)
    }
    startGame(){
        this.snake = [
            {x: 13, y: 13},
            {x: 13, y: 12}
        ]
        this.direction = {x: 0 ,y: 1}
        this.score = 0
        this.updateBackground()
        this.food = this.createFood()
        this.drawFood()
        this.scoreElement.innerText = "Score: " + this.score
        this.moveSnake()
        this.gameOver = false       
    }
}


const canvas = document.querySelector("#snakeCanvas");
const ctx = canvas.getContext("2d");

let snake = new Snake(ctx)
const startButon = document.querySelector("#start-game")
startButon.addEventListener("click", () => {
    snake.startGame()
    startButon.style.display = "none"
})

document.addEventListener("keydown", (e) => {
    switch(e.key){
        case "ArrowLeft":
            if(snake.direction.x !== 1){
               snake.direction.x = -1
               snake.direction.y = 0
            }
            break;
        case "ArrowRight":
            if(snake.direction.x !== -1){
               snake.direction.x = 1
               snake.direction.y = 0
            }
            break;
        case "ArrowUp":
            if(snake.direction.y !== 1){
               snake.direction.y = -1
               snake.direction.x = 0
            }
            break;
        case "ArrowDown":
            if(snake.direction.y !== -1){
               snake.direction.y = 1
               snake.direction.x = 0
            }
            break;
    }
})
const playAgainButton = document.querySelector('.play-again-button')
playAgainButton.addEventListener('click', () => {
    snake.startGame()
    snake.gameOverCard.classList.remove('show')
})
if (!localStorage.getItem('visited')) {
    localStorage.setItem('visited', 'true');
    localStorage.setItem('topScore', JSON.stringify(0));
}
snake.topScore.innerText = 'Top Score: ' + JSON.parse(localStorage.getItem('topScore'))

const mobileControls = document.querySelectorAll('.mobile-control')
const mobileControlsContainer = document.querySelector('.mobile-controls')
mobileControls[0].addEventListener('click',() => {
    if(snake.direction.y !== 1){
        snake.direction.x = 0
        snake.direction.y = -1
        mobileControls[0].style.backgroundColor = '#0f8000'
        mobileControls[1].style.backgroundColor = '#000000'
        mobileControls[2].style.backgroundColor = '#000000'
        mobileControls[3].style.backgroundColor = '#000000'
    }
}
)
mobileControls[1].addEventListener('click',() => {
    if(snake.direction.x !== 1){
        snake.direction.x = -1
        snake.direction.y = 0
        mobileControls[0].style.backgroundColor = '#000000'
        mobileControls[1].style.backgroundColor = '#0f8000'
        mobileControls[2].style.backgroundColor = '#000000'
        mobileControls[3].style.backgroundColor = '#000000'
    }
})
mobileControls[2].addEventListener('click',() => {
    if(snake.direction.x !== -1){
        snake.direction.x = 1
        snake.direction.y= 0
        mobileControls[0].style.backgroundColor = '#000000'
        mobileControls[1].style.backgroundColor = '#000000'
        mobileControls[2].style.backgroundColor = '#0f8000'
        mobileControls[3].style.backgroundColor = '#000000'
    }    
})
mobileControls[3].addEventListener('click',() => {
    if(snake.direction.y !== -1){
        snake.direction.x = 0
        snake.direction.y = 1
        mobileControls[0].style.backgroundColor = '#000000'
        mobileControls[1].style.backgroundColor = '#000000'
        mobileControls[2].style.backgroundColor = '#000000'
        mobileControls[3].style.backgroundColor = '#0f8000'
    }
})
const scoreBoard = document.querySelector('.score-board')
function adjustCanvasSize() {
    if (window.innerWidth < 400) {
        canvas.width = 300;
        canvas.height = 300;
        scoreBoard.style.width = '300px'
        mobileControlsContainer.style.width = '300px'
        mobileControlsContainer.style.display = 'flex'
    } else {
        canvas.width = 390; 
        canvas.height = 390;
        scoreBoard.style.width = '390px'
        mobileControlsContainer.style.width = '390px'
        mobileControlsContainer.style.display = 'none'
    }
    snake.pixelSize = canvas.width / snake.pixels; 
    snake.updateBackground(); 

    // snake.drawSnake();
}

adjustCanvasSize();


window.addEventListener("resize", adjustCanvasSize);
