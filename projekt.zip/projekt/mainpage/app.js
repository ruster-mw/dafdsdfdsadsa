document.addEventListener('DOMContentLoaded', function () {
    // --- DOM ELEMENTS ---
    const findButton = document.querySelector(".find-button");
    const card1 = document.querySelector("#card1");
    const card1Title = document.querySelector(".card1-title");
    const card1Description = document.querySelector(".card1-description");
    const card2 = document.querySelector("#card2");
    const card2Title = document.querySelector(".card2-title");
    const card2Description = document.querySelector(".card2-description");
    const cardsButton = document.querySelector(".cards-button");
    const hamburgerButton = document.querySelector('.hamburger-button');
    const menuMobile = document.querySelector('.mobile-menu');
    const hamburgerLineIcon = document.querySelector(".hamburger-icon-lines");
    const hamburgerXIcon = document.querySelector(".hamburger-icon-x");
    const loginForm = document.querySelector('.login-form');
    const loginPopUp = document.querySelector('.login-popup');
    const accountLink = document.querySelector('.account-link');
    const accountLinks = document.querySelectorAll('.account-links');
    const signUpForm = document.querySelector('.signup-form');
    const gamesList = document.querySelector('.games-list');
    const categories = document.querySelector('.categories-list');
    const accountLogIn = document.getElementById('account-login');
    const loginBackground = document.querySelector('.login-background');
    const loginCard = document.querySelector('.login-card');
    const accountSignUp = document.getElementById('account-signup');
    const signUpbackground = document.querySelector('.signup-background');
    const signUpCard = document.querySelector('.signup-card');
    const closeLogin = document.querySelector('.close-login');
    const closeSignUp = document.querySelector('.close-signup');

    // --- DATA ---
    const games = [
        {
            title: "hangman",
            link: "../hangman/hangman.html",
            description: "Hangman is a single-player word-guessing game where you try to figure out a hidden word one letter at a time. Each incorrect guess brings a stick-figure closer to being fully drawn. You win by guessing the word before the hangman is complete.",
            image: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4f/Hangman%2C_English%2C_3.png/800px-Hangman%2C_English%2C_3.png",
            type: "puzzle",
        },
        {
            title: "tic-tac-toe",
            link: "../tic-tac-toe/tictactoe.html",
            description: "Tic-Tac-Toe is a classic two-player game played on a 3x3 grid. Players take turns marking Xs and Os in empty squares. The first player to align three of their marks horizontally, vertically, or diagonally wins. If all squares are filled without a winner, the game ends in a draw.",
            image: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/32/Tic_tac_toe.svg/800px-Tic_tac_toe.svg.png",
            type: "2v2",
        },
        {
            title: "memory match",
            link: "../memory-match/memory.html",
            description: "Memory Match is a single or multiplayer card game that tests your ability to remember. Players take turns flipping over two cards at a time, trying to find matching pairs. The player with the most matches at the end wins.",
            image: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Memory_game.svg/800px-Memory_game.svg.png",
            type: "puzzle",
        },
        {
            title: "snake",
            link: "../snake/snake.html",
            description: "Snake is a single-player arcade game where you control a growing snake that must eat food to gain points. The snake gets longer with each meal and the challenge is to avoid running into the walls or yourself.",
            image: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Snake_game.svg/800px-Snake_game.svg.png",
            type: "infinte",
        },
        {
            title: "cactus jump",
            link: "../cactus-jump/cactus.html",
            description: "cactus jump is a simple, endless runner game where you control a cactus that jumps over obstacles. The goal is to keep the cactus running as long as possible without hitting any obstacles.",
            image: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/Dino_jump.svg/800px-Dino_jump.svg.png",
            type: "infinte",
        }
    ];

    let counter = 0;
    let sequencecounter = 0;
    let activeItem = null;

    // --- HERO SECTION BUTTON ---
    if (findButton) {
        findButton.addEventListener('click', function () {
            document.getElementById('games-catalog').scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    }

    // --- HERO CARDS LOGIC ---
    function showCard1() {
        card2.classList.add("card2-animator-fade-out");
        card1.classList.remove("card2-animator-fade-out");
        setTimeout(function () {
            card1.style.zIndex = "1";
            card2.style.zIndex = "-1";
        }, 600);
    }
    function showCard2() {
        card1.classList.add("card2-animator-fade-out");
        card2.classList.remove("card2-animator-fade-out");
        setTimeout(function () {
            card2.style.zIndex = "1";
            card1.style.zIndex = "-1";
        }, 600);
    }
    if (cardsButton) {
        cardsButton.addEventListener('click', function () {
            if (counter > games.length - 1) {
                counter = 0;
                if (games.length % 2 !== 0) {
                    if (sequencecounter % 2 === 0) {
                        card2Title.textContent = games[counter].title;
                        card2Description.textContent = games[counter].description;
                        showCard2();
                    } else {
                        card1Title.textContent = games[counter].title;
                        card1Description.textContent = games[counter].description;
                        showCard1();
                    }
                    counter++;
                    sequencecounter++;
                } else {
                    card1Title.textContent = games[counter].title;
                    card1Description.textContent = games[counter].description;
                    showCard1();
                    counter++;
                }
            } else {
                if (sequencecounter % 2 === 0) {
                    if (counter % 2 === 0) {
                        card1Title.textContent = games[counter].title;
                        card1Description.textContent = games[counter].description;
                        showCard1();
                        counter++;
                    } else {
                        card2Title.textContent = games[counter].title;
                        card2Description.textContent = games[counter].description;
                        showCard2();
                        counter++;
                    }
                } else {
                    if (counter % 2 === 0) {
                        card2Title.textContent = games[counter].title;
                        card2Description.textContent = games[counter].description;
                        showCard2();
                        counter++;
                    } else {
                        card1Title.textContent = games[counter].title;
                        card1Description.textContent = games[counter].description;
                        showCard1();
                        counter++;
                    }
                }
            }
        });
        // Initialize hero cards
        card2Title.textContent = games[games.length - 1].title;
        card2Description.textContent = games[games.length - 1].description;
    }

    // --- HAMBURGER MENU ---
    function showMenu() {
        menuMobile.classList.toggle('menu-show');
        hamburgerLineIcon.classList.toggle('hide');
        hamburgerXIcon.classList.toggle('hide');
    }
    if (hamburgerButton) {
        hamburgerButton.addEventListener('click', showMenu);
    }

    // --- GAMES LIST ---
    if (gamesList) {
        games.forEach(game => {
            const card = document.createElement('li');
            card.classList.add('game');
            const img = document.createElement('img');
            img.src = game.image;
            img.classList.add('game-image');
            img.alt = game.title;
            const title = document.createElement('h2');
            title.textContent = game.title;
            title.classList.add('game-title');
            card.appendChild(img);
            card.appendChild(title);
            card.dataset.type = game.type;
            card.addEventListener('click', function () {
                window.location.href = game.link;
            });
            gamesList.appendChild(card);
        });
    }
    const gameCards = document.querySelectorAll('.game');

    // --- CATEGORY FILTER ---
    if (categories) {
        categories.addEventListener('click', function (e) {
            if (e.target.tagName === 'LI') {
                if (activeItem) {
                    activeItem.style.backgroundColor = '';
                    activeItem.style.color = '';
                    activeItem.firstElementChild.setAttribute('fill', '#00C49D');
                    activeItem.firstElementChild.setAttribute('stroke', '#00C49D');
                }
                activeItem = e.target;
                activeItem.style.backgroundColor = '#00C49D';
                activeItem.firstElementChild.setAttribute('fill', '#000272');
                activeItem.firstElementChild.setAttribute('stroke', '#000272');
                activeItem.style.color = '#000272';
                gameCards.forEach(game => {
                    if (game.dataset.type === e.target.dataset.type || e.target.dataset.type === 'all') {
                        game.style.display = 'flex';
                    } else {
                        game.style.display = 'none';
                    }
                });
            }
        });
    }

    // --- LOGIN/SIGNUP POPUPS ---
    function showSignUpCard() {
        signUpbackground.classList.toggle('show-background');
        signUpCard.classList.toggle('show-signup-card');
    }
    function showLoginCard() {
        loginBackground.classList.toggle('show-background');
        loginCard.classList.toggle('show-login-card');
    }
    if (accountLogIn) accountLogIn.addEventListener('click', showLoginCard);
    if (accountSignUp) accountSignUp.addEventListener('click', showSignUpCard);
    if (closeLogin) closeLogin.addEventListener('click', showLoginCard);
    if (closeSignUp) closeSignUp.addEventListener('click', showSignUpCard);

    // --- ACCOUNT LINKS VISIBILITY ---
    function showLoginForm() {
        if (localStorage.getItem('accountLinks')) {
            const links = JSON.parse(localStorage.getItem('accountLinks'));
            accountLinks[0].style.display = links[0];
            accountLinks[1].style.display = links[1];
            accountLink.style.display = links[2];
        }
    }
    if (!localStorage.getItem('visited')) {
        localStorage.setItem('visited', 'true');
        localStorage.setItem('accountLinks', JSON.stringify(['block', 'block', 'none']));
    }

    // --- LOGIN FORM SUBMIT ---
    const registerdAccount = [
        {
            email: 'a@a.pl',
            password: 'password'
        }
    ];
    if (loginForm) {
        loginForm.addEventListener('submit', function (e) {
            e.preventDefault();
            let email = document.querySelector('#login-email').value;
            let password = document.querySelector('#login-password').value;
            let found = false;
            registerdAccount.forEach(function (account) {
                if (account.email == email && account.password == password) {
                    found = true;
                    loginPopUp.classList.add('popup-show');
                    loginPopUp.textContent = "successfully logged in";
                    localStorage.setItem('accountLinks', JSON.stringify(['none', 'none', 'block']));
                    showLoginForm();
                    setTimeout(function () {
                        loginPopUp.classList.remove('popup-show');
                    }, 2000);
                }
            });
            if (!found) {
                loginPopUp.classList.add('popup-show');
                loginPopUp.textContent = "Invalid email or password";
                setTimeout(function () {
                    loginPopUp.classList.remove('popup-show');
                }, 2000);
            }
        });
    }

    // --- SIGNUP FORM SUBMIT ---
    if (signUpForm) {
        signUpForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const username = document.querySelector('#signup-username')?.value;
            const signInEmail = document.querySelector('#signup-email')?.value;
            const password = document.querySelector('#signup-password')?.value;
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>/?]).{7,}$/;
            if (!emailRegex.test(signInEmail)) {
                loginPopUp.classList.add('popup-show');
                loginPopUp.textContent = "Invalid email format";
                setTimeout(function () {
                    loginPopUp.classList.remove('popup-show');
                }, 2000);
            }
            // Add further signup validation and logic here
        });
    }
});