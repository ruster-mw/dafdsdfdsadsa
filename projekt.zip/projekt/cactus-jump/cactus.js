class Cactus {
    constructor(ctx) {
        this.ctx = ctx
        this.gravity = 0.6
        this.lift = -12
        this.cactusY = 0
        this.cactusVY = 0
        this.cactusWidth = 40
        this.cactusHeight = 40
        this.ground = canvas.height - this.cactusHeight
        this.obstacles = []
        this.score = 0
        this.gameOver = false
        this.scoreElement = document.querySelector("#score")
        this.gameOverCard = document.querySelector(".game-over-card")
        this.topScore = document.querySelector(".top-score")
        this.spawnRate = 90
        this.frames = 0
        this.cactusSprite = new Image()
        this.cactusSprite.src = '../images/cactus.png'
        this.dinoSprite = new Image()
        this.dinoSprite.src = '../images/dino.png'
        this.speed = 8
    }
    updateBackground() {
        this.ctx.fillStyle = "#222222"
        this.ctx.fillRect(0, 0, canvas.width, canvas.height)
    }
    drawcactus() {
        this.ctx.fillStyle = "black"
        this.ctx.drawImage(this.cactusSprite,50,this.cactusY, this.cactusWidth, this.cactusHeight)
    }
    drawObstacles() {
        this.ctx.fillStyle = "green"
        this.obstacles.forEach(obs => {
            this.ctx.drawImage(this.dinoSprite,obs.x, obs.y, obs.width, obs.height)
        })
    }
    createObstacle() {
        const height = 30 + Math.random() * 30
        this.obstacles.push({
            x: canvas.width,
            y: this.ground + this.cactusHeight - height,
            width: 20,
            height: height
        })
    }
    updateObstacles() {
        this.obstacles.forEach(obs => {
            obs.x -= this.speed
        })
        this.obstacles = this.obstacles.filter(obs => obs.x + obs.width > 0)
    }
    checkCollision() {
        return this.obstacles.some(obs => {
            return (
                50 < obs.x + obs.width &&
                50 + this.cactusWidth > obs.x &&
                this.cactusY + this.cactusHeight > obs.y
            )
        })
    }
    jump() {
        if (this.cactusY === this.ground) {
            this.cactusVY = this.lift
        }
    }
    movecactus() {
        this.updateBackground()
        this.frames++

        if (this.frames % this.spawnRate === 0) {
            this.createObstacle()
        }

        this.cactusVY += this.gravity
        this.cactusY += this.cactusVY

        if (this.cactusY > this.ground) {
            this.cactusY = this.ground
            this.cactusVY = 0
        }

        this.updateObstacles()
        this.drawcactus()
        this.drawObstacles()

        if (this.checkCollision()) {
            this.gameOver = true
        }

        if (!this.gameOver) {
            this.score++
            this.scoreElement.innerText = "Score: " + this.score
            requestAnimationFrame(() => this.movecactus())
        } else {
            this.gameOverCard.classList.add("show")
            this.gameOverCard.children[2].innerText = "your score is: " + this.score
            if (this.score > JSON.parse(localStorage.getItem("topcactusScore"))) {
                localStorage.setItem("topcactusScore", JSON.stringify(this.score))
                this.topScore.innerText = "Top Score: " + this.score
            }
        }
    }
    startGame() {
        this.cactusY = this.ground
        this.cactusVY = 0
        this.obstacles = []
        this.score = 0
        this.frames = 0
        this.updateBackground()
        this.scoreElement.innerText = "Score: " + this.score
        this.gameOver = false
        this.movecactus()
    }
}


const canvas = document.querySelector("#cactusCanvas")
const ctx = canvas.getContext("2d")
canvas.style.backgroundColor = "#2a2a2a"
const cactus = new Cactus(ctx)
cactus.startGame()

document.addEventListener('keydown', (e) => {
    if (e.code ===  'Space') {
        cactus.jump()
    }
})
if (!localStorage.getItem('visited')) {
    localStorage.setItem('visited', 'true')
    localStorage.setItem('topcactusScore', JSON.stringify(0))
}
cactus.topScore.innerText = 'Top Score: ' + JSON.parse(localStorage.getItem('topcactusScore'))

const playAgainButton = document.querySelector(".play-again-button")
playAgainButton.addEventListener("click", () => {
    cactus.gameOverCard.classList.remove("show")
    cactus.startGame()
})
const scoreBoard = document.querySelector('.score-board')
const mobileControl = document.querySelector('.mobile-control')
mobileControl.addEventListener('click', () => {
    cactus.jump()
})
function adjustCanvasSize() {
    if (window.innerWidth < 500) {
        canvas.width = 320
        canvas.height = 300
        cactus.speed = 6
        scoreBoard.style.width = '300px'
        mobileControl.style.width = '300px'
    } else {
        canvas.width = 490;
        canvas.height = 300
        cactus.speed = 8
        scoreBoard.style.width = '390px'
        mobileControl.style.width = '390px'
    }
    cactus.pixelSize = canvas.width / cactus.pixels; 
    cactus.updateBackground(); 
}

adjustCanvasSize();

window.addEventListener("resize", adjustCanvasSize);

